<?php include "db.php"; ?>

<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<div class="card">
<h2>User Registration</h2>

<form method="post">

<input name="username" placeholder="Username" required>
<input name="college" placeholder="College" required>
<input name="email" placeholder="Email" required>
<input name="mobile" placeholder="Mobile" required>

<button name="register">Register</button>

</form>

</div>

<?php
if(isset($_POST['register'])){
    $conn->query("INSERT INTO users(username,college_name,email,mobile)
    VALUES('$_POST[username]','$_POST[college]','$_POST[email]','$_POST[mobile]')");

    echo "<script>alert('Registered Successfully');window.location='events.php';</script>";
}
?>

</body>
</html>