<?php
$conn = new mysqli("localhost","root","8466","ticketevent2");

if($conn->connect_error){
    die("Connection failed");
}
?>