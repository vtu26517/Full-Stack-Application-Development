<?php 
include "db.php";

/* ================= BOOK EVENT ================= */
if(isset($_POST['book'])){
    $id = $_POST['id'];
    $qty = $_POST['qty'];

    $e = $conn->query("SELECT * FROM events WHERE event_id=$id")->fetch_assoc();

    if($e['available_tickets'] >= $qty){

        $total = $qty * $e['price'];

        // INSERT BOOKING
        $conn->query("INSERT INTO bookings(user_id,event_id,quantity,total_price)
        VALUES(1,$id,$qty,$total)");

        // GET BOOKING ID
        $booking_id = $conn->insert_id;

        // UPDATE TICKETS
        $conn->query("UPDATE events 
        SET available_tickets = available_tickets - $qty 
        WHERE event_id = $id");

        // REDIRECT TO PAYMENT (QR SCANNER PAGE)
        echo "<script>
        alert('Booking Successful');
        window.location='payment.php?booking_id=$booking_id&amount=$total';
        </script>";
        exit();
    } else {
        echo "<script>alert('Not enough tickets');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Events</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<a href="dashboard.php">⬅ Back</a>

<h2>Events</h2>

<?php
$res = $conn->query("SELECT * FROM events");

while($e = $res->fetch_assoc()){
?>

<div class="card">

<h3><?php echo $e['name']; ?></h3>
<p>Date: <?php echo $e['event_date']; ?></p>
<p>Price: ₹<?php echo $e['price']; ?></p>
<p>Available: <?php echo $e['available_tickets']; ?></p>

<form method="post">
<input type="hidden" name="id" value="<?php echo $e['event_id']; ?>">
<input type="number" name="qty" placeholder="Tickets" required>
<button name="book">Book</button>
</form>

</div>

<?php } ?>

</body>
</html>