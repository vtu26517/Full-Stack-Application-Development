<?php
include "db.php";

if(!isset($_GET['booking_id']) || !isset($_GET['amount'])){
    echo "Invalid Access";
    exit();
}

$booking_id = $_GET['booking_id'];
$amount = $_GET['amount'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment</title>
<link rel="stylesheet" href="style.css">

<style>
.payment-box{
width:400px;
margin:50px auto;
padding:25px;
background:white;
border-radius:10px;
box-shadow:0 0 10px gray;
text-align:center;
}
.method{
margin:15px 0;
text-align:left;
}
.hidden{
display:none;
}
input, select{
width:90%;
padding:10px;
margin:8px 0;
border-radius:5px;
border:1px solid #ccc;
}
button{
padding:10px;
background:green;
color:white;
border:none;
cursor:pointer;
width:100%;
}
</style>

<script>
function showOption(type){
    document.getElementById("upi").style.display="none";
    document.getElementById("card").style.display="none";
    document.getElementById("netbanking").style.display="none";

    document.getElementById(type).style.display="block";
}
</script>

</head>

<body>

<div class="payment-box">

<h2>💳 Payment</h2>
<p><strong>Total Amount:</strong> ₹<?php echo $amount; ?></p>

<!-- PAYMENT OPTIONS -->
<div class="method">
<label><input type="radio" onclick="showOption('upi')"> UPI</label><br>
<label><input type="radio" onclick="showOption('card')"> Credit/Debit Card</label><br>
<label><input type="radio" onclick="showOption('netbanking')"> Net Banking</label>
</div>

<!-- UPI -->
<div id="upi" class="hidden">
<h3>Scan & Pay (UPI)</h3>

<img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=<?php echo $booking_id; ?>" />

<p>Scan using PhonePe / GPay / Paytm</p>

<form method="post">
<input type="hidden" name="method" value="UPI">
<button name="pay">Confirm Payment</button>
</form>
</div>

<!-- CARD -->
<div id="card" class="hidden">
<h3>Enter Card Details</h3>

<form method="post">
<input type="text" name="card_number" placeholder="Card Number" required>
<input type="text" name="expiry" placeholder="MM/YY" required>
<input type="text" name="cvv" placeholder="CVV" required>

<input type="hidden" name="method" value="Card">
<button name="pay">Pay Now</button>
</form>
</div>

<!-- NET BANKING -->
<div id="netbanking" class="hidden">
<h3>Select Bank</h3>

<form method="post">
<select name="bank" required>
<option value="">Select Bank</option>
<option>SBI</option>
<option>HDFC</option>
<option>ICICI</option>
<option>Axis Bank</option>
</select>

<input type="hidden" name="method" value="NetBanking">
<button name="pay">Proceed</button>
</form>
</div>

</div>

<?php
// PAYMENT PROCESS
if(isset($_POST['pay'])){

    $method = $_POST['method'];

    // INSERT INTO PAYMENTS TABLE
    $conn->query("INSERT INTO payments(booking_id, amount, payment_method, payment_status)
    VALUES('$booking_id','$amount','$method','Paid')");

    // UPDATE BOOKINGS TABLE
    $conn->query("UPDATE bookings SET payment_status='Paid' WHERE booking_id='$booking_id'");

    // REDIRECT TO SUCCESS PAGE
    header("Location: payment_success.php?booking_id=$booking_id");
    exit();
}
?>

</body>
</html>