<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<h1>Event Dashboard</h1>

<div class="card">
<h2>Navigation</h2>

<a href="register.php"><button>Register</button></a>
<a href="events.php"><button>Events</button></a>
<a href="admin.php"><button>Admin</button></a>
<a href="admin_login.php"><button>Admin</button></a>
</div>

</body>
</html>