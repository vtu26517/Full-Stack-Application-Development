<?php include "db.php"; ?>

<!DOCTYPE html>
<html>
<head>
<title>Bookings</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<a href="dashboard.php">⬅ Back</a>

<h2>Bookings</h2>

<?php
$res=$conn->query("SELECT b.*,u.username,e.name 
FROM bookings b
JOIN users u ON b.user_id=u.user_id
JOIN events e ON b.event_id=e.event_id");

while($b=$res->fetch_assoc()){
?>

<div class="card">
<p>User: <?php echo $b['username']; ?></p>
<p>Event: <?php echo $b['name']; ?></p>
<p>Status: <?php echo $b['payment_status']; ?></p>

<?php if($b['payment_status']=="Pending"){ ?>
<a href="?pay=<?php echo $b['booking_id']; ?>">Pay</a>
<?php } ?>

</div>

<?php } ?>

<?php
if(isset($_GET['pay'])){
    $conn->query("UPDATE bookings SET payment_status='Paid' WHERE booking_id=$_GET[pay]");
    header("Location: bookings.php");
}
?>

</body>
</html>