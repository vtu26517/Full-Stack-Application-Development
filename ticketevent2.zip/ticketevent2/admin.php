<?php
session_start();
include "db.php";

/* 🔐 PROTECT ADMIN ONLY */
if(!isset($_SESSION['admin'])){
    header("Location: admin_login.php");
    exit();
}

/* ➕ ADD EVENT */
if(isset($_POST['add'])){
    $name = $_POST['name'];
    $date = $_POST['date'];
    $price = $_POST['price'];
    $tickets = $_POST['tickets'];

    $conn->query("INSERT INTO events(name,event_date,price,available_tickets)
    VALUES('$name','$date','$price','$tickets')");
}

/* ❌ DELETE EVENT */
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $conn->query("DELETE FROM events WHERE event_id=$id");
    header("Location: admin.php");
}

/* 📊 FETCH DATA */
$events = $conn->query("SELECT * FROM events");

$bookings = $conn->query("
SELECT b.*, u.username, e.name 
FROM bookings b
JOIN users u ON b.user_id = u.user_id
JOIN events e ON b.event_id = e.event_id
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<link rel="stylesheet" href="style.css">
<script src="https://unpkg.com/html5-qrcode"></script>
</head>

<body>

<h1>Admin Dashboard</h1>

<!-- 🔓 LOGOUT -->
<a href="logout.php"><button>Logout</button></a>
<a href="dashboard.php"><button>Back</button></a>

<hr>

<!-- ➕ ADD EVENT -->
<div class="card">
<h2>Add Event</h2>

<form method="post">
<input type="text" name="name" placeholder="Event Name" required>
<input type="date" name="date" required>
<input type="number" name="price" placeholder="Price" required>
<input type="number" name="tickets" placeholder="Tickets" required>
<button name="add">Add Event</button>
</form>
</div>

<hr>

<!-- 📋 VIEW EVENTS -->
<div class="card">
<h2>All Events</h2>

<?php while($e = $events->fetch_assoc()){ ?>

<div class="card">
<h3><?php echo $e['name']; ?></h3>
<p>Date: <?php echo $e['event_date']; ?></p>
<p>Price: ₹<?php echo $e['price']; ?></p>
<p>Tickets: <?php echo $e['available_tickets']; ?></p>

<a href="?delete=<?php echo $e['event_id']; ?>">
<button style="background:red;">Delete</button>
</a>
</div>

<?php } ?>
</div>

<hr>

<!-- 📊 BOOKINGS -->
<div class="card">
<h2>Bookings & Payment Status</h2>

<?php while($b = $bookings->fetch_assoc()){ ?>

<div class="card">
<p><strong>User:</strong> <?php echo $b['username']; ?></p>
<p><strong>Event:</strong> <?php echo $b['name']; ?></p>
<p><strong>Tickets:</strong> <?php echo $b['quantity']; ?></p>
<p><strong>Total:</strong> ₹<?php echo $b['total_price']; ?></p>

<p>
<strong>Status:</strong> 
<?php 
if($b['payment_status'] == "Paid"){
    echo "<span style='color:green;'>Paid</span>";
} else {
    echo "<span style='color:red;'>Pending</span>";
}
?>
</p>
</div>

<?php } ?>
</div>

<hr>

<!-- 📷 SCANNER -->
<div class="card">
<h2>Scan Ticket (Admin Only)</h2>
<div id="reader"></div>
</div>

<script>
function onScanSuccess(qr){
    window.location.href = "verify.php?booking_id=" + qr;
}

new Html5QrcodeScanner("reader",{fps:10,qrbox:200}).render(onScanSuccess);
</script>

</body>
</html>