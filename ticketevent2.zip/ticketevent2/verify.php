<?php
include "db.php";

if(!isset($_GET['booking_id'])){
    echo "Invalid Access";
    exit();
}

$id = $_GET['booking_id'];

$res = $conn->query("SELECT * FROM bookings WHERE booking_id='$id'");
?>

<!DOCTYPE html>
<html>
<head>
<title>Verification</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<div class="card">

<?php
if($res->num_rows > 0){

    $data = $res->fetch_assoc();

    if($data['payment_status'] == "Paid"){
        echo "<h2 style='color:green;'>✅ VALID TICKET</h2>";
        echo "<p>Booking ID: $id</p>";
    } else {
        echo "<h2 style='color:red;'>❌ PAYMENT NOT DONE</h2>";
    }

} else {
    echo "<h2 style='color:red;'>❌ FAKE QR CODE</h2>";
}
?>

</div>

</body>
</html>