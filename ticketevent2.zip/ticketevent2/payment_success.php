<?php
include "db.php";

$booking_id = $_GET['booking_id'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment Success</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<div class="card">

<h2 style="color:green;">✅ Payment Successful</h2>

<p>Your booking is confirmed.</p>

<p><strong>Booking ID:</strong> <?php echo $booking_id; ?></p>

<h3>Your Ticket QR Code</h3>

<img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=<?php echo $booking_id; ?>">

<p>Show this QR at event entry</p>

<br>

<a href="dashboard.php">
<button>Go to Dashboard</button>
</a>

</div>

</body>
</html>